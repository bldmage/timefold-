# timefold
TimeFold is a responsive digital time-capsule app for writing messages to your future self. Create a capsule, capture how you’re feeling with a mood tag, and choose a date to unlock it. When it opens, add a reflection to compare then and now. The app includes a dashboard, countdowns, a searchable archive, and local browser storage. Built with: React, JavaScript, Vite, HTML, and CSS.
