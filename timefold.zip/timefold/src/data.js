export const seedCapsules = [
  { id: 'seed-1', title: 'The things I’m learning to let go', note: 'I hope you remember that growth is not always loud. Sometimes it is choosing peace, one ordinary afternoon at a time.', createdAt: '2025-08-14', unlockAt: '2026-11-14', mood: 'becoming', color: 'lilac', opened: false, reflection: '' },
  { id: 'seed-2', title: 'A promise for the next chapter', note: 'Keep making room for the unexpected. The best parts of this year were never on the plan.', createdAt: '2025-12-01', unlockAt: '2026-10-15', mood: 'hopeful', color: 'peach', opened: false, reflection: '' },
  { id: 'seed-3', title: 'Remember this small, good day', note: 'Coffee on the balcony. That song on repeat. Nothing to fix, nowhere to rush.', createdAt: '2026-02-22', unlockAt: '2026-12-22', mood: 'grateful', color: 'mint', opened: false, reflection: '' },
];

export const moods = [
  { id: 'becoming', label: 'Becoming', emoji: '✳' }, { id: 'hopeful', label: 'Hopeful', emoji: '☼' },
  { id: 'grateful', label: 'Grateful', emoji: '♡' }, { id: 'uncertain', label: 'Uncertain', emoji: '☾' },
  { id: 'brave', label: 'Brave', emoji: '✦' }, { id: 'dreaming', label: 'Dreaming', emoji: '✧' },
];
