export const STORAGE_KEY = 'timefold-capsules-v1';

export function readCapsules() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : null;
  } catch (error) {
    console.error('TimeFold could not read saved capsules.', error);
    return null;
  }
}

export function getDaysLeft(date) {
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const target = new Date(`${date}T00:00:00`);
  return Math.max(0, Math.ceil((target - today) / 86400000));
}

export function formatDate(date) {
  return new Date(`${date}T00:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}
