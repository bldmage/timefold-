import React, { useEffect, useState } from 'react';
import { ArrowLeft, LockKeyhole, X } from 'lucide-react';
import { formatDate, getDaysLeft } from '../utils.js';

export default function CapsuleModal({ capsule, onClose, onOpen, onReflect }) {
  const [reflection, setReflection] = useState(capsule.reflection || '');
  const days = getDaysLeft(capsule.unlockAt); const locked = days > 0 && !capsule.opened;
  useEffect(() => { const fn = e => e.key === 'Escape' && onClose(); window.addEventListener('keydown', fn); return () => window.removeEventListener('keydown', fn); }, [onClose]);
  return <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && onClose()}><section className="modal capsule-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button className="modal-close" onClick={onClose} aria-label="Close"><X size={18}/></button>
    <div className="modal-eyebrow">{locked ? <><LockKeyhole size={13}/> SEALED UNTIL {formatDate(capsule.unlockAt).toUpperCase()}</> : 'A NOTE FROM YOUR PAST SELF'}</div>
    <div className="modal-stamp">{locked ? '✳' : '✧'}</div><h2 id="modal-title">{locked ? 'Not quite yet.' : capsule.title}</h2>
    {locked ? <><p className="locked-message">This capsule is still finding its way to you. You’ll be able to unfold it in <strong>{days} {days === 1 ? 'day' : 'days'}</strong>.</p><div className="locked-date">Written {formatDate(capsule.createdAt)} <span>·</span> Opens {formatDate(capsule.unlockAt)}</div></> : <>
      <blockquote>{capsule.note}</blockquote><div className="modal-meta">Written {formatDate(capsule.createdAt)} <span>·</span> Feeling <em>{capsule.mood}</em></div>
      <div className="reflection-box"><label htmlFor="reflection">THEN, MEET NOW</label><p>What would you like to tell the person who wrote this?</p><textarea id="reflection" rows="3" value={reflection} onChange={e => setReflection(e.target.value)} placeholder="Leave a thought for the timeline…"/><button className="text-button" onClick={() => { onReflect(capsule.id, reflection); if (!capsule.opened) onOpen(capsule); onClose(); }}>Save reflection <ArrowLeft className="arrow-rotate" size={15}/></button></div>
    </>}
  </section></div>;
}
