import React from 'react';
import { Aperture, Archive, Clock3, Compass, Plus, Settings2 } from 'lucide-react';

export default function Sidebar({ active, onNavigate, onCreate, counts }) {
  const links = [
    { id: 'today', label: 'Today', icon: Compass }, { id: 'timeline', label: 'Timeline', icon: Clock3 }, { id: 'archive', label: 'Archive', icon: Archive },
  ];
  return <aside className="sidebar">
    <a className="brand" href="#today" onClick={(e) => { e.preventDefault(); onNavigate('today'); }} aria-label="TimeFold home"><span className="brand-mark"><Aperture size={20} strokeWidth={1.6} /></span><span>timefold<span className="brand-dot">.</span></span></a>
    <div className="side-section-label">YOUR SPACE</div>
    <nav aria-label="Main navigation" className="side-nav">{links.map(({ id, label, icon: Icon }) => <button key={id} className={`nav-item ${active === id ? 'selected' : ''}`} onClick={() => onNavigate(id)}><Icon size={17} strokeWidth={1.7} /><span>{label}</span>{id === 'archive' && counts > 0 && <span className="nav-count">{counts}</span>}</button>)}</nav>
    <div className="side-card"><div className="side-card-icon">✳</div><p>A little note for your future self can change everything.</p><button onClick={onCreate}>Write one <span>↗</span></button></div>
    <div className="side-bottom"><button className="nav-item settings" onClick={() => onNavigate('settings')}><Settings2 size={17} /><span>Settings</span></button><div className="profile"><div className="avatar">M</div><div><strong>My space</strong><span>Personal archive</span></div><span className="online-dot" /></div></div>
  </aside>;
}
