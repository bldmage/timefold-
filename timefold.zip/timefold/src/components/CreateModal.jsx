import React, { useState } from 'react';
import { ArrowRight, X } from 'lucide-react';
import { moods } from '../data.js';

export default function CreateModal({ onClose, onCreate }) {
  const [title, setTitle] = useState(''); const [note, setNote] = useState(''); const [unlockAt, setUnlockAt] = useState(''); const [mood, setMood] = useState('becoming'); const [error, setError] = useState('');
  const today = new Date(); today.setDate(today.getDate() + 1); const minDate = today.toISOString().slice(0, 10);
  function submit(e) { e.preventDefault(); if (!title.trim() || !note.trim() || !unlockAt) { setError('Fill in each field to seal your capsule.'); return; } if (unlockAt < minDate) { setError('Choose a date at least one day from today.'); return; } onCreate({ title: title.trim(), note: note.trim(), unlockAt, mood }); }
  return <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && onClose()}><section className="modal create-modal" role="dialog" aria-modal="true" aria-labelledby="create-title"><button className="modal-close" onClick={onClose} aria-label="Close"><X size={18}/></button><div className="modal-eyebrow">A LITTLE LETTER THROUGH TIME</div><div className="create-heading-icon">✳</div><h2 id="create-title">Write to a future you.</h2><p className="create-intro">Say what you need to hear. Choose when it finds you.</p>
    <form onSubmit={submit} noValidate><label className="field-label" htmlFor="capsule-title">GIVE THIS MOMENT A NAME</label><input id="capsule-title" maxLength="70" value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. When I need a little courage"/><label className="field-label" htmlFor="capsule-note">YOUR NOTE</label><textarea id="capsule-note" rows="4" maxLength="1200" value={note} onChange={e => setNote(e.target.value)} placeholder="What do you want future you to remember?"/><div className="char-count">{note.length} / 1200</div>
      <span className="field-label">HOW ARE YOU FEELING?</span><div className="mood-picker" role="group" aria-label="Choose a mood">{moods.map(m => <button type="button" key={m.id} className={`mood-choice ${mood === m.id ? 'active' : ''}`} onClick={() => setMood(m.id)} aria-pressed={mood === m.id}><span>{m.emoji}</span>{m.label}</button>)}</div>
      <label className="field-label" htmlFor="unlock-date">WHEN SHOULD IT FIND YOU?</label><input id="unlock-date" type="date" min={minDate} value={unlockAt} onChange={e => setUnlockAt(e.target.value)}/><p className="form-hint">Your capsule will stay sealed until this date.</p>{error && <p className="form-error" role="alert">{error}</p>}<button className="submit-button" type="submit">Seal this capsule <ArrowRight size={16}/></button>
    </form></section></div>;
}
