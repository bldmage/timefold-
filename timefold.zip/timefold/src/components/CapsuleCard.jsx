import React from 'react';
import { ArrowUpRight, LockKeyhole, Sparkles } from 'lucide-react';
import { formatDate, getDaysLeft } from '../utils.js';

export function FeaturedCapsule({ capsule, onOpen }) {
  const days = getDaysLeft(capsule.unlockAt); const unlocked = days === 0 || capsule.opened;
  return <article className="featured-card">
    <div className="feature-orbit orbit-one"/><div className="feature-orbit orbit-two"/><div className="feature-stars">✦ <span>·</span> ✧</div>
    <div className="featured-copy"><div className="eyebrow light"><span className="status-dot" />{unlocked ? 'READY TO UNFOLD' : 'YOUR NEXT UNFOLDING'}</div><h2>{unlocked ? 'The wait is over.' : <>A message from<br /><em>your past self.</em></>}</h2><p>{unlocked ? 'A little piece of then, ready for the person you are today.' : 'You left this here for a reason. Let the days bring you closer.'}</p>
      <button className="feature-button" onClick={() => onOpen(capsule)}>{unlocked ? 'Open your capsule' : `Unlocks ${formatDate(capsule.unlockAt)}`} {unlocked ? <ArrowUpRight size={15} /> : <LockKeyhole size={14} />}</button>
    </div>
    <div className="countdown-wrap"><div className="countdown-number">{unlocked ? '✧' : String(days).padStart(2, '0')}</div><div className="countdown-caption">{unlocked ? 'READY' : 'DAYS TO GO'}</div><div className="countdown-rule"/><div className="countdown-date">{formatDate(capsule.unlockAt)}</div></div>
    <div className="feature-footer"><span><Sparkles size={13} /> A future you moment</span><span>#{capsule.id.slice(-4).toUpperCase()}</span></div>
  </article>;
}

export function CapsuleCard({ capsule, onOpen }) {
  const days = getDaysLeft(capsule.unlockAt); const unlocked = days === 0 || capsule.opened;
  return <button className={`capsule-card ${capsule.color || 'lilac'}`} onClick={() => onOpen(capsule)}>
    <div className="card-top"><span className={`mood-tag mood-${capsule.mood}`}>{capsule.mood}</span><span className="card-lock">{unlocked ? <span className="ready-label">READY ↗</span> : <LockKeyhole size={14} />}</span></div>
    <div className="card-content"><h3>{capsule.title}</h3><p>{unlocked ? 'Ready to unfold, whenever you are.' : `A little patience. ${days} ${days === 1 ? 'day' : 'days'} left.`}</p></div>
    <div className="card-bottom"><span>Written {formatDate(capsule.createdAt)}</span><span className="card-arrow"><ArrowUpRight size={16} /></span></div>
  </button>;
}
