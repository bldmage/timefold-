import React, { useEffect, useMemo, useState } from 'react';
import { ArrowDownRight, ArrowUpRight, CalendarDays, ChevronDown, CircleHelp, Plus, Search, SlidersHorizontal, Sparkles } from 'lucide-react';
import { seedCapsules, moods } from './data.js';
import { readCapsules, STORAGE_KEY, formatDate, getDaysLeft } from './utils.js';
import Sidebar from './components/Sidebar.jsx';
import { CapsuleCard, FeaturedCapsule } from './components/CapsuleCard.jsx';
import CapsuleModal from './components/CapsuleModal.jsx';
import CreateModal from './components/CreateModal.jsx';

function moodLabel(id) { return moods.find(m => m.id === id)?.label || id; }

export default function App() {
  const [capsules, setCapsules] = useState(() => readCapsules() || seedCapsules);
  const [active, setActive] = useState('today'); const [showCreate, setShowCreate] = useState(false); const [selected, setSelected] = useState(null);
  const [filter, setFilter] = useState('all'); const [query, setQuery] = useState(''); const [storageError, setStorageError] = useState(false);
  useEffect(() => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(capsules)); setStorageError(false); } catch (e) { setStorageError(true); console.error('TimeFold could not save capsules.', e); } }, [capsules]);
  const today = new Date(); const dateText = today.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
  const upcoming = useMemo(() => capsules.filter(c => !c.opened && getDaysLeft(c.unlockAt) > 0).sort((a,b) => a.unlockAt.localeCompare(b.unlockAt)), [capsules]);
  const featured = upcoming[0] || capsules.find(c => c.opened) || capsules[0];
  const filtered = capsules.filter(c => {
    const state = getDaysLeft(c.unlockAt) === 0 || c.opened ? 'ready' : 'sealed';
    const matchFilter = filter === 'all' || state === filter || c.mood === filter;
    return matchFilter && `${c.title} ${c.note} ${c.mood}`.toLowerCase().includes(query.toLowerCase());
  });
  function create(data) { const item = { ...data, id: `tf-${Date.now()}`, createdAt: new Date().toISOString().slice(0,10), color: ['lilac','peach','mint'][capsules.length % 3], opened: false, reflection: '' }; setCapsules(prev => [item, ...prev]); setShowCreate(false); setActive('today'); }
  function selectCapsule(c) { if (getDaysLeft(c.unlockAt) === 0 && !c.opened) { const opened = { ...c, opened: true }; setCapsules(prev => prev.map(item => item.id === c.id ? opened : item)); setSelected(opened); } else setSelected(c); }
  function markOpened(c) { setCapsules(prev => prev.map(item => item.id === c.id ? { ...item, opened: true } : item)); setSelected({ ...c, opened: true }); }
  function saveReflection(id, reflection) { setCapsules(prev => prev.map(c => c.id === id ? { ...c, reflection } : c)); }
  return <div className="app-shell"><Sidebar active={active} onNavigate={setActive} onCreate={() => setShowCreate(true)} counts={capsules.length}/><main className="main-content"><header className="topbar"><div className="breadcrumbs"><span>My space</span><span className="crumb-slash">/</span><strong>{active === 'today' ? 'Today' : active[0].toUpperCase()+active.slice(1)}</strong></div><div className="topbar-actions"><button className="icon-button" aria-label="Help" title="How TimeFold works"><CircleHelp size={17}/></button><div className="top-avatar">M</div></div></header>
    {storageError && <div className="storage-warning" role="alert">Your browser couldn't save changes. Your capsules may not be here next time.</div>}
    {active === 'today' && <>
      <section className="welcome-row"><div><div className="eyebrow date-eyebrow"><CalendarDays size={13}/>{dateText}</div><h1>Good things take <em>their time.</em></h1><p className="welcome-sub">A small place to leave a little something for the person you’re becoming.</p></div><button className="primary-button" onClick={() => setShowCreate(true)}><Plus size={17}/> Create a capsule</button></section>
      {featured ? <section className="feature-section"><div className="section-kicker"><span>THE NEXT UNFOLDING</span><span className="micro-dot"/> <span>TAKE A MOMENT</span></div><FeaturedCapsule capsule={featured} onOpen={selectCapsule}/></section> : <section className="empty-feature"><span>✳</span><h2>Your first little time travel?</h2><p>Write a note now. Let a future you find it when they need it.</p><button className="primary-button" onClick={() => setShowCreate(true)}><Plus size={17}/> Create your first capsule</button></section>}
      <section className="capsules-section"><div className="section-heading"><div><div className="section-kicker">YOUR LITTLE TIME CAPSULES</div><h2>Waiting in the wings <span className="count-pill">{capsules.length}</span></h2></div><button className="subtle-link" onClick={() => setActive('archive')}>View archive <ArrowUpRight size={14}/></button></div>
        {capsules.length ? <div className="capsule-grid">{capsules.slice().sort((a,b) => a.unlockAt.localeCompare(b.unlockAt)).slice(0,3).map(c => <CapsuleCard key={c.id} capsule={c} onOpen={selectCapsule}/>)}</div> : null}
      </section>
      <footer className="home-footer"><div className="footer-quote"><span className="quote-sparkle">✳</span><span>“The future belongs to those who believe in the beauty of their dreams.”</span><span className="quote-credit">— Eleanor Roosevelt</span></div><div className="footer-note">A GENTLE REMINDER <span>✦</span> YOU’RE RIGHT ON TIME</div></footer>
    </>}
    {(active === 'archive' || active === 'timeline') && <section className="library-view"><div className="library-header"><div><div className="eyebrow date-eyebrow"><Sparkles size={13}/>{active === 'archive' ? 'YOUR PERSONAL ARCHIVE' : 'A RECORD OF THEN & NOW'}</div><h1>{active === 'archive' ? 'Every little time capsule.' : 'A timeline of you.'}</h1><p className="welcome-sub">{active === 'archive' ? 'All the things you’ve left for future you.' : 'Each note is a small marker along the way.'}</p></div><button className="primary-button" onClick={() => setShowCreate(true)}><Plus size={17}/> Create a capsule</button></div>
      <div className="library-tools"><div className="search-box"><Search size={16}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Find a capsule…" aria-label="Search capsules"/></div><div className="filter-wrap"><SlidersHorizontal size={15}/><select value={filter} onChange={e => setFilter(e.target.value)} aria-label="Filter capsules"><option value="all">All capsules</option><option value="sealed">Still sealed</option><option value="ready">Ready to open</option>{moods.map(m => <option key={m.id} value={m.id}>{m.label}</option>)}</select><ChevronDown size={14}/></div><span className="results-count">{filtered.length} {filtered.length === 1 ? 'capsule' : 'capsules'}</span></div>
      {filtered.length ? <div className="library-grid">{filtered.map(c => <CapsuleCard key={c.id} capsule={c} onOpen={selectCapsule}/>)}</div> : <div className="empty-state"><div>⌕</div><h2>{query ? 'Nothing found just yet.' : 'A little room for your first note.'}</h2><p>{query ? 'Try another word or clear your search.' : 'Your timeline starts with a message only you can send.'}</p>{!query && <button className="primary-button" onClick={() => setShowCreate(true)}><Plus size={17}/> Write your first capsule</button>}</div>}
    </section>}
    {active === 'settings' && <section className="library-view"><div className="eyebrow date-eyebrow">YOUR SPACE</div><h1>A quiet corner, just for you.</h1><div className="settings-panel"><div className="settings-icon">✳</div><h2>About your TimeFold</h2><p>Your capsules are stored in this browser on this device. Clearing browser data will remove them.</p><div className="security-note"><strong>A note on privacy</strong><p>TimeFold is a frontend-only demo. Its date-based locks are a visual experience, not security. Capsules are saved in localStorage and can be read by anyone with access to this browser. Don’t store private or sensitive messages here.</p></div></div></section>}
    </main>
    <button className="mobile-create" onClick={() => setShowCreate(true)} aria-label="Create a capsule"><Plus size={22}/></button>
    {showCreate && <CreateModal onClose={() => setShowCreate(false)} onCreate={create}/>}{selected && <CapsuleModal capsule={selected} onClose={() => setSelected(null)} onOpen={markOpened} onReflect={saveReflection}/>}
  </div>;
}
