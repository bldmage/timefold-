# TimeFold

A responsive, frontend-only time-capsule app built with React, JavaScript, Vite, HTML, and CSS. TimeFold lets you leave a note for a future version of yourself, choose an unlock date, attach a mood, and reflect on it when it is ready.

## Run locally

```sh
npm install
npm run dev
```

Vite prints a local URL after the development server starts. Create a production build with `npm run build`; preview it with `npm run preview`.

## Features

- Dashboard with a featured countdown and upcoming capsules
- Create flow with title, note, future unlock date, and six mood tags
- Date-based sealed and ready states, archive search and filters
- Then-vs-Now reflection saved alongside an opened capsule
- Browser localStorage persistence and a graceful save-error notice
- Reusable UI components, keyboard-dismissable dialogs, semantic labels, responsive layouts, empty states, and form validation

## Privacy and security

TimeFold is a frontend-only demo. Unlock dates are enforced only by the UI and browser clock; they are not secure locks. Capsule contents are stored as readable data in localStorage on this device. Anyone with access to the browser or developer tools can read or change them. Do not use this demo for private or sensitive messages. A production version would need authenticated server storage and server-side authorization for unlocking.
